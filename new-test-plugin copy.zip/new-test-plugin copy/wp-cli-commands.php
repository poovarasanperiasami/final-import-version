<?php
// WP-CLI command classes are defined here.

/**
 * Handles the installation and activation of plugins.
 */
class Plugin_Activator_Command {
    /**
     * Installs and activates a given list of plugins.
     */
    public function run($args, $assoc_args) {
        list($plugins) = $args;
        $plugin_list = explode(',', $plugins);
        foreach ($plugin_list as $plugin_slug) {
            $plugin_path = WP_PLUGIN_DIR . '/' . $plugin_slug . '/' . $plugin_slug . '.php';
            if (!file_exists($plugin_path)) {
                WP_CLI::runcommand('plugin install ' . $plugin_slug . ' --activate');
            } else {
                if (!is_plugin_active($plugin_path)) {
                    WP_CLI::runcommand('plugin activate ' . $plugin_slug);
                } else {
                    WP_CLI::log("{$plugin_slug} is already active.");
                }
            }
        }
    }
}

/**
 * Handles the installation and activation of a theme.
 */
class Theme_Activator_Command {
    /**
     * Installs and activates a given theme.
     */
    public function run($args, $assoc_args) {
        list($theme_slug) = $args;
        if (!wp_get_theme($theme_slug)->exists()) {
            WP_CLI::runcommand('theme install ' . $theme_slug . ' --activate');
        } else {
            if (wp_get_theme()->template != $theme_slug) {
                WP_CLI::runcommand('theme activate ' . $theme_slug);
            } else {
                WP_CLI::log("{$theme_slug} theme is already active.");
            }
        }
    }
}

WP_CLI::add_command('plugin_activator', 'Plugin_Activator_Command');
WP_CLI::add_command('theme_activator', 'Theme_Activator_Command');
