<?php
/*
Plugin Name: Custom XML Importer
Description: A custom plugin to import XML data and manage plugins/themes.
Version: 1.0
Author: Your Name
*/

require_once(ABSPATH . 'wp-admin/includes/class-wp-upgrader.php');
require_once(ABSPATH . 'wp-admin/includes/plugin.php');
require_once(ABSPATH . 'wp-admin/includes/theme.php');

// Increase memory limit
ini_set('memory_limit', '512M');

add_action('admin_menu', 'custom_xml_importer_menu');

function custom_xml_importer_menu() {
    add_menu_page('Custom XML Importer Settings', 'XML Importer', 'manage_options', 'custom-xml-importer', 'custom_xml_importer_page');
}

function custom_xml_importer_page() {
    ?>
    <div class="wrap">
        <h1>Custom XML Importer Settings</h1>
        <form method="post" action="">
            <?php wp_nonce_field('custom-xml-import'); ?>
            <input type="submit" name="custom_xml_import_button" class="button button-primary" value="Import XML">
        </form>
        <?php
        if (isset($_POST['custom_xml_import_button']) && check_admin_referer('custom-xml-import')) {
            $import_results = custom_xml_importer_run_import();
            foreach ($import_results as $result) {
                echo '<div class="' . (strpos($result, 'failed') !== false ? 'error' : 'updated') . '"><p>' . $result . '</p></div>';
            }
        }
        ?>
    </div>
    <?php
}

function custom_xml_importer_run_import() {
    do_action('custom_xml_importer_before_run');

    $plugin_dir = plugin_dir_path(__FILE__);
    $file_paths = [
        $plugin_dir . 'metforms.xml',
        $plugin_dir . 'headerandfooter.xml',
        $plugin_dir . 'posts-data.xml',
        $plugin_dir . 'page-import.xml'
    ];

    require_once(ABSPATH . 'wp-admin/includes/import.php');
    if (!class_exists('WP_Import')) {
        require_once($plugin_dir . 'class-wp-import.php');
    }

    custom_xml_importer_install_and_activate_plugins();
    custom_xml_importer_install_and_activate_theme();

    $import_results = [];
    $wp_importer = new WP_Import();
    $wp_importer->fetch_attachments = true;

    foreach ($file_paths as $file_path) {
        if (!file_exists($file_path)) {
            $import_results[] = "The file does not exist: $file_path";
            continue;
        }
        ob_start();
        $import_result = $wp_importer->import($file_path);
        ob_end_clean();
        $import_results[] = is_wp_error($import_result) ? 'Import failed for ' . basename($file_path) . ': ' . $import_result->get_error_message() : 'Import successful for ' . basename($file_path);
    }

    // Import Elementor settings from JSON file
    $json_file_path = $plugin_dir . 'site-settings.json';
    if (file_exists($json_file_path)) {
        $import_results[] = import_elementor_settings_from_json($json_file_path);
    } else {
        $import_results[] = "The JSON file does not exist: $json_file_path";
    }

    do_action('custom_xml_importer_after_run');
    return $import_results;
}

function custom_xml_importer_install_and_activate_plugins() {
    $plugins = [
        'elementor', 'elementskit-lite', 'jeg-elementor-kit', 'metform', 'header-footer-elementor'
    ];

    $upgrader = new Plugin_Upgrader(new WP_Ajax_Upgrader_Skin());
    foreach ($plugins as $plugin_slug) {
        $plugin_path = WP_PLUGIN_DIR . '/' . $plugin_slug . '/' . $plugin_slug . '.php';
        if (!file_exists($plugin_path)) {
            $upgrader->install('https://downloads.wordpress.org/plugin/' . $plugin_slug . '.zip');
        }
        if (!is_plugin_active($plugin_path)) {
            activate_plugin($plugin_path);
            echo '<div class="updated"><p>Activated plugin: ' . $plugin_slug . '</p></div>';
        }
    }
}

function custom_xml_importer_install_and_activate_theme() {
    $theme_slug = 'hello-elementor';
    $theme_path = WP_CONTENT_DIR . '/themes/' . $theme_slug;

    if (!file_exists($theme_path)) {
        $upgrader = new Theme_Upgrader(new WP_Ajax_Upgrader_Skin());
        $upgrader->install('https://downloads.wordpress.org/theme/' . $theme_slug . '.zip');
    }

    $current_theme = wp_get_theme();
    if ($current_theme->get_template() !== $theme_slug) {
        switch_theme($theme_slug);
        echo '<div class="updated"><p>Activated theme: ' . $theme_slug . '</p></div>';
    }
}

function import_elementor_settings_from_json($file_path) {
    $file_contents = file_get_contents($file_path);
    $settings = json_decode($file_contents, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        return 'Failed to parse JSON file: ' . json_last_error_msg();
    }

    return update_elementor_settings($settings);
}

function update_elementor_settings($settings) {
    if (!did_action('elementor/loaded')) {
        return 'Elementor is not loaded.';
    }

    $elementor = \Elementor\Plugin::instance();

    // Get the active kit ID
    $kit_manager = $elementor->kits_manager;
    $active_kit_id = $kit_manager->get_active_id();
    $kit = $kit_manager->get_kit_for_frontend($active_kit_id);
    
    if (isset($settings['settings'])) {
        foreach ($settings['settings'] as $key => $value) {
            if($key=='system_colors'){
                $kit->set_settings('system_colors', $value);
                $kit->save(['settings' => $kit->get_settings()]);
            }
            if($key=='custom_colors'){
                $kit->set_settings('custom_colors', $value);
                $kit->save(['settings' => $kit->get_settings()]);
            }
            if($key=='system_typography'){
                $kit->set_settings('system_typography', $value);
                $kit->save(['settings' => $kit->get_settings()]);
            }  
            if($key=='custom_typography'){
                $kit->set_settings('custom_typography', $value);
                $kit->save(['settings' => $kit->get_settings()]);
            }  
        }
        return '<div class="updated"><p>Elementor settings imported successfully.</p></div>';
    } else {
        return '<div class="error"><p>Invalid settings data in JSON file.</p></div>';
    }
}
